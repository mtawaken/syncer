#!/bin/bash

kubectl delete podgroups --all
kubectl delete sparkapp --all
